<section id="blogs" >
    <div class="container py-4 ">
        <h4 class="font-rubik font-size-20 ">Latest Blogs</h4>
        <hr>
        <div class="owl-carousel owl-theme  ">
            <div class="item ">
                <div class="card border-0 font-rale mr-5"style="width:18rem;">
                    <h5 class="card-title font-size-16">Blogs you should not miss</h5>
                    <img src="./assets/blog/blog1.jpg"alt="cart image"class="card-img-top">
                    <p class="card-text font-size-14 text-black-50 py-1">Technorati is useful and most popular technology website in the world of internet which helps bloggers and tech blog owners to get more views on their website and provides a lot of quality technology guides and news. Apart from this it also covers guides related to android, apple, gadgets etc. and much more. 11. BusinessInsider.com</p>
                    <a href="#" class="color-second text-left">Redirect</a>
                </div>
            </div>
            <div class="item" >
                <div class="card border-0 font-rale mr-5"style="width:18rem;">
                    <h5 class="card-title font-size-16">Software world</h5>
                    <img src="./assets/blog/blog2.jpg"alt="cart image"class="card-img-top">
                    <p class="card-text font-size-14 text-black-50 py-1">With new technologies flooding every day, it is hard to keep up with all the updates. Blogs are a valuable resource for keeping up with recent innovations, communicating with fellow developers and getting a feel of what software development is all about. Living in an era of content overload, it is hard to find the best developer blogs out there</p>
                    <a href="#" class="color-second text-left">Read more</a>
                </div>
            </div>
            <div class="item">
                <div class="card border-0 font-rale mr-5"style="width:18rem;">
                    <h5 class="card-title font-size-16">Mobile technologies</h5>
                    <img src="./assets/blog/Blog3.jpg"alt="cart image"class="card-img-top">
                    <p class="card-text font-size-14 text-black-50 py-1">The mobile technology had exponentially extended its support for the past century with interactive user interface, investment, technology development and still in vigor. Internet Connectivity and regular Operating System update makes use of the latest trends in mobile technology to outstand among other technologies</p>
                    <a href="#" class="color-second text-left">Redirect</a>
                </div>
            </div>
        </div>
    </div>
</section>
